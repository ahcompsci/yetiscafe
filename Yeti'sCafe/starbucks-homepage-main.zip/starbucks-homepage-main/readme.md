# Starbucks Homepage Clone

HTML/CSS clone of Starbucks.com. This is from my [YouTube tutorial](https://youtu.be/x_n2FGNsm0o)
